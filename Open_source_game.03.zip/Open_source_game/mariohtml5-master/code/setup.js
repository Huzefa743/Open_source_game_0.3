/**
	Just create the global mario object.
	Code by Rob Kleffner, 2011
*/

var Mario = {};